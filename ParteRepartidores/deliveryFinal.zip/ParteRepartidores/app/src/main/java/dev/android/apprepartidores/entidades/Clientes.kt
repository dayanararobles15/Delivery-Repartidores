package dev.android.apprepartidores.entidades

data class clientePersona(


    var idCliente: Int,
var nombre: String,
var apellido :String


)