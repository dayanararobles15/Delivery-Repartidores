package dev.android.apprepartidores.entidades


    data class productoItem(

        var idProducto: Int,
        var producto: String,
    )

